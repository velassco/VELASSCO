// DEM_ingest_client_fake.cpp : Defines the entry point for the console application.
//

#include <stdio.h>
#include <unistd.h>
#include <time.h>

#include "../gen-cpp/Ingestor.h"
#include <thrift/protocol/TBinaryProtocol.h>
#include <thrift/transport/TSocket.h>
#include <thrift/transport/TTransportUtils.h>


using namespace std;
using namespace apache::thrift;
using namespace apache::thrift::protocol;
using namespace apache::thrift::transport;

using namespace DEM_Ingest;

using namespace boost;


int main(int argc, char* argv[])
{
   boost::shared_ptr<TTransport> socket(new TSocket("localhost", 9090));
   boost::shared_ptr<TTransport> transport(new TBufferedTransport(socket));
   boost::shared_ptr<TProtocol> protocol(new TBinaryProtocol(transport));
   IngestorClient client(protocol);

   WSADATA wsaData = {};
   WORD wVersionRequested = MAKEWORD(2, 2);
   int err = WSAStartup(wVersionRequested, &wsaData);

   try {
      transport->open();

      Simulation grabSimulation;
      string retStatus;
      std::vector<Timestep> tsList;

      grabSimulation.__set_name("John Deere grab simulation 1");
      for (int t = 0; t < 4; t++) {
         Timestep *ts = new Timestep();
         double time_value = t;
         ts->__set_time_value(time_value);
         for (int p = 0; p < 10; p++) {

         }
         tsList.push_back(*ts);
      }
      grabSimulation.__set_consists_of(tsList);

      client.store_DEM_Simulation(retStatus, grabSimulation);
      if (retStatus.compare("OK") == 0) {
         printf("DEM simulation stored successfully\n");
      } else {
         printf("Error ocurred - %s", retStatus.c_str());
      }

      transport->close();
   } catch (TException &tx) {
      printf("ERROR: %s\n", tx.what());
   }

   return 0;
}

